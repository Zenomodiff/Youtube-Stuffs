# Bebas Neue by Dharma Type


## License
This font is licensed under the SIL Open Font License 1.1  
http://scripts.sil.org/OFL  
http://scripts.sil.org/OFL-FAQ_web


## Detail
Please visit http://bebasneue.com/ for more detail and web fonts.


## FAQ
Q_ Can I use this for a commercial product?  
A_ Yes, You can.


## Support free font project
Our free fonts are free even for commercial use. You can use them without any purchases.  
But we welcome your support for free font project.  
Please visit  http://dharmatype.com/support


## Contact
Ryoichi Tsunekawa  
Dharma Type  
http://dharmatype.com  
info@dharmatype.com  
